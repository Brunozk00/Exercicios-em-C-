﻿int contador = 0, quantidadeacimade5 = 0, quantidadedivisivel3 = 0, numero;
string numerosSorteados = " ";

Random rand = new Random();

while (contador < 20)
{
    numero = rand.Next(0, 10);

    numerosSorteados += numero + " ";

    if (numero > 5)
    {
        quantidadeacimade5++;
    }
    
    if(numero % 3 == 0)
    {
        quantidadedivisivel3++;
    }

    contador++;
}

Console.WriteLine(numerosSorteados + "foram sorteados");
Console.WriteLine(quantidadeacimade5 + " números estão acima de 5");
Console.WriteLine(quantidadedivisivel3 + " números são divisíveis por 3");
