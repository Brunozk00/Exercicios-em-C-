﻿int contador = 0, idade, qtdemulheres = 0, qtdeHomens = 0, mediaidade = 0,
    mediaidadeH = 0, qtdeMulheresmais20 = 0;
string sexo = "";

while (contador < 5)
{
    Console.WriteLine("Digite sua idade: ");
    idade = Convert.ToInt32(Console.ReadLine());

    Console.WriteLine("Digite seu sexo: M ou F");
    sexo = Console.ReadLine();

    if (sexo.ToUpper() == "F")
    {
        qtdemulheres++;

        if (idade > 20)
        {
            qtdeMulheresmais20++;
        }
    }
    else
    {
        qtdeHomens++;
        mediaidadeH += idade;
    }

    mediaidade += idade;

    contador++;
}

Console.WriteLine("quantos homens foram cadastrados" + qtdeHomens);
Console.WriteLine(" quantas mulheres foram cadastradas" + qtdemulheres);
Console.WriteLine("a media de idade do grupo" + (mediaidade / 5));
Console.WriteLine("a media de idade dos homens " + (mediaidade / qtdeHomens));
Console.WriteLine("quantas mulheres tem mais de 20 anos" + (qtdeMulheresmais20));
