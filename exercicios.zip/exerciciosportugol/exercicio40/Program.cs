﻿int contador = 100;

while (contador >= 0)
{
    Console.Write(contador + " ");
    contador -= 5;
}
Console.Write("Acabou!");
