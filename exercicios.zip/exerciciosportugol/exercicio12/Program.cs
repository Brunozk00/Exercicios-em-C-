﻿decimal preco, desconto = 5, valorFinal;

Console.WriteLine("Digie o preço do produo: ");
preco = Convert.ToDecimal(Console.ReadLine());

valorFinal = preco - (desconto / 100) * preco;

Console.WriteLine("O valor com desconto é de: R$ " + valorFinal);
