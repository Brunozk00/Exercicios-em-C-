﻿int valor1, valor2, resultado;

Console.WriteLine("Digite um valor: ");
valor1 = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Digite um valor: ");
valor2 = Convert.ToInt32(Console.ReadLine());

resultado = valor1 + valor2;

Console.WriteLine("a soma dos dois numeros é igual " + resultado);