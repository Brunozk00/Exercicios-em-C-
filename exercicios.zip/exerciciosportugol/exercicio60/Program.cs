﻿for (int contador = 0; contador <= 40; contador += 5)
{
    Console.WriteLine(contador + " ");
}

Console.WriteLine("Acabou!");