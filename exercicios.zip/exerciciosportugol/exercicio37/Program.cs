﻿int contador = 6;

while (contador <=11)
{
    Console.Write(contador + " ");
    contador++;
}

Console.Write("Acabou!");