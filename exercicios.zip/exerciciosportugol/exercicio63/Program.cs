﻿Console.WriteLine("Digite um numero: ");
int numero = Convert.ToInt32(Console.ReadLine());

for(int cont = 0; cont <= numero; cont++)
{
    Console.Write(cont + " "); 
}

Console.WriteLine();
