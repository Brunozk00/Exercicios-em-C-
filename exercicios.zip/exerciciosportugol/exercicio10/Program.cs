﻿decimal largura, altura, areatotal;
int tamanhoAreaPintadaLt = 2;

Console.WriteLine("Digite a largura da parede");
largura = Convert.ToDecimal(Console .ReadLine());

Console.WriteLine("Digite a altura da parede");
altura = Convert.ToDecimal(Console .ReadLine());

areatotal = largura * altura;
Console.WriteLine("serão necessários: " + (areatotal / tamanhoAreaPintadaLt) + "litros de tinta ");
