﻿decimal a, b, c;

Console.WriteLine("Digite o tamanho do lado A: ");
a = Convert.ToDecimal(Console.ReadLine());

Console.WriteLine("Digite o tamanho do lado b:");
b= Convert.ToDecimal(Console.ReadLine());

Console.WriteLine("Digite o tamanho do lado c:");
c= Convert.ToDecimal(Console.ReadLine());

if ((a + b) > c &&
    (a + c) > b &&
    (b + c) > a)
{
    if (a == b && a == c && c == b)
    {
        Console.WriteLine("O seu Triangulo é um equilatero");

    }
    else if (a == b || b == c || c == a)
    {
        Console.WriteLine("Seu triangolo é um isocles");
    }
    else
    {
        Console.WriteLine("Seu triangulo é um escaleno");
    }
}

else
{
    Console.WriteLine("Seu triangulo não é funcional");
}
