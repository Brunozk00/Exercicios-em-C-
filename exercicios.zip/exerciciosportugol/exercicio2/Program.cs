﻿string nome;
Console.WriteLine("Qual o seu nome");

nome = Console.ReadLine();

Console.WriteLine("Ola " + nome + " é um prazer te conhece-lo");