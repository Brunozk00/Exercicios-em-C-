﻿string nome;
decimal salario;

Console.WriteLine("Nome do funcionario");
nome = Console.ReadLine();

Console.WriteLine("salario");
string salarioStr = Console.ReadLine();
salario = Convert.ToDecimal(salarioStr);

Console.WriteLine("O funcionario " + nome + "tem um salario de R$ " + salario + " em agosto");
