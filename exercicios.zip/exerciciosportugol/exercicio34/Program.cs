﻿string tipoCarro;
int quantidadeDias, kmPercorridos;
decimal valorcobranca = 0;

Console.WriteLine("Digite o tipo de carro (popular ou luxo):");
tipoCarro = Console.ReadLine();

Console.WriteLine("Digite a quantidade de dias do aluguel: ");
quantidadeDias = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Digite os kms percorridos: ");
kmPercorridos = Convert.ToInt32(Console.ReadLine());

if(tipoCarro == "popular")
{
    valorcobranca = 90 * quantidadeDias;
    if(kmPercorridos <= 100)
    {
        valorcobranca += 0.20M * kmPercorridos;
    }
    else
    {
        valorcobranca += 0.10M * kmPercorridos;
    }
}
else
{
    valorcobranca = 90 * quantidadeDias;
    if (kmPercorridos <= 200)
    {
        valorcobranca += 0.30M * kmPercorridos;
    }
    else
    {
        valorcobranca += 0.25M * kmPercorridos;
    }
}

Console.WriteLine("O valor do aluguel foi de: R$ " + valorcobranca);