﻿using System.Data;

int anoNascimeto, idade;

Console.WriteLine("Digite o ano do nascimento: ");
anoNascimeto = Convert.ToInt32(Console.ReadLine());


idade = DateTime.Now.Year - anoNascimeto;

if(idade <= 18)
{
    Console.WriteLine("Faltam: " + (18 - idade) + " anos para o alistamento");

}
else
{
    Console.WriteLine("Já se Passaram: " + (idade - 18) + " do ano do alistamento");

}