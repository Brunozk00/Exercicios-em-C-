﻿string nome, sexo;

decimal valorCompras, percentualDescontohomem = 0.05M, percentualDesconoMulher = 0.13M;

Console.WriteLine("Escreva seu nome: ");
nome = Console.ReadLine();

Console.WriteLine("Digite seu sexo: M ou F");
sexo = Console.ReadLine();

Console.WriteLine("Digite o total das compras: ");
valorCompras = Convert.ToDecimal(Console.ReadLine());

if (sexo.ToUpper() == "F")
{
    Console.WriteLine("O valor do descono é de: R$ " +
        (valorCompras * percentualDesconoMulher));

}
else
{
    Console.WriteLine("O valor do desconto é de: R$ " +
        (valorCompras * percentualDescontohomem));
}

