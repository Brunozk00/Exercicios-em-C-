﻿int numero;

Console.WriteLine("digite um numero");
numero = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("O antecessor de " + numero +"é"+ (numero - 1));
Console.WriteLine("O sucessor " + (numero +1));

