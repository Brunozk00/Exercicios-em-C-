﻿decimal largura, comprimento, areatotal;

Console.WriteLine("Digite a largura do terreno: ");
largura = Convert.ToDecimal(Console.ReadLine());

Console.WriteLine("Digite o comprimento do terreno:");
comprimento = Convert.ToDecimal(Console.ReadLine());

areatotal = largura * comprimento;

string mensagem = "Área total: " + areatotal + " .\nClassificação: ";

if(areatotal < 100)
{
    Console.WriteLine(mensagem + "TERRENO POPULAR");
}
else if (areatotal <= 500)
{
    Console.WriteLine(mensagem + "TERRENO MASTER");
}
else
{
    Console.WriteLine(mensagem + "TERRENO VIP");
}