﻿int contador = 10;

while (contador >= 3)
{
    Console.Write(contador + " ");
    contador--;
}
Console.Write("Acabou");