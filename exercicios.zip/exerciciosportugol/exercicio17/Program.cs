﻿int velocidadeCarro, limiteVelocidade = 80;
decimal valormulta = 5, valorPagar;

Console.WriteLine("Digite a velocidade do carro: ");
velocidadeCarro = Convert.ToInt32(Console.ReadLine());

if (velocidadeCarro > limiteVelocidade) ;
{

    valorPagar = (velocidadeCarro - limiteVelocidade) * valormulta;
    Console.WriteLine("Você passou acima do limite permitido, multa: R$" + valorPagar);
}

