﻿int distancia;
decimal valortotal;

Console.WriteLine("Digite a distância a percorrer: ");
distancia = Convert.ToInt32(Console.ReadLine());

if (distancia <= 200)
{
    valortotal = distancia * 0.50M;

}
else
{
    valortotal = distancia * 0.45M;

}

Console.WriteLine("O valor total a pagar é de: R$ " + valortotal);