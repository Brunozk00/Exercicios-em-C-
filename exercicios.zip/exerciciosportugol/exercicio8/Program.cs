﻿decimal numero;

Console.WriteLine("digite um numero: ");
numero = Convert.ToDecimal(Console.ReadLine());

Console.WriteLine("O dobro de " + numero + " é " + (numero * 2));

Console.WriteLine(" A terça parte de" + numero + " é " + (numero / 3));