﻿int contador = 0;
decimal preco, maiorvalordigitado = 0, menorvalordigitado = 0;

while (contador < 8)
{
    Console.WriteLine("Digie o valor do produto: ");
    preco = Convert.ToDecimal(Console.ReadLine());

    if(contador == 0)
    {
        maiorvalordigitado = preco;
        menorvalordigitado = preco;

    }
    if (preco > maiorvalordigitado)
    {
        maiorvalordigitado = preco;
    }

    if (preco < maiorvalordigitado)
    {
        menorvalordigitado = preco;
    }
    contador++;

}
Console.WriteLine("O maior valor digitado foi: R$ " + maiorvalordigitado);
Console.WriteLine("O menor valor digitado foi: R$ " + menorvalordigitado);
