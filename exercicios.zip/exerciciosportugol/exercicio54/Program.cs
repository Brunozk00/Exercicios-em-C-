﻿decimal peso, somaAlturas = 0, qtdMais90Kg = 0, qtdMenos50Kgmenos_60m = 0, qtdMais1_90mMais100kg = 0, contador = 0;
int altura = 0;

while (contador < 7)
{
    Console.WriteLine("Digite seu peso: ");
    peso = Convert.ToDecimal(Console.ReadLine());

    Console.WriteLine("Digite sua altura (cm):");
    altura = Convert.ToInt32(Console.ReadLine());

    somaAlturas += altura;
    {
        qtdMais90Kg++;
    }

    if(peso < 50 && altura < 160)
    {
        qtdMenos50Kgmenos_60m++;
    }

    if (altura > 190 && peso > 100)
    {
        qtdMais1_90mMais100kg++;
    }

    contador++;
}

Console.WriteLine("Qual foi a média de altura do grupo: " + (somaAlturas / 7));
Console.WriteLine("Quantas pessoas pesam mais de 90Kg: " + qtdMais90Kg);
Console.WriteLine("Quantas pesoas que pesam menos de 50kg e tem menos de 1.60m:" + qtdMenos50Kgmenos_60m);
Console.WriteLine("Quantas pesoas que medem mais de 1.90 pesam mais de 100kg:" + qtdMais1_90mMais100kg);