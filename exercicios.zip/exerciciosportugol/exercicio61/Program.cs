﻿for (int cont = 100; cont >=0; cont -= 10)
{
    Console.Write(cont + " ");
}

Console.WriteLine("Acabou!");