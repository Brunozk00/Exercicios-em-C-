﻿decimal valorcasa, salariocomprador, valorMensalcasa, limiteComprometimentoSalario;
int anosApagar;

Console.WriteLine("Digite o valor da casa :");
valorcasa = Convert.ToDecimal(Console.ReadLine());

Console.WriteLine("Digite o salário do comprador: ");
salariocomprador = Convert.ToDecimal(Console.ReadLine());

Console.WriteLine("Digite o prazo em anos para pagamento: ");
anosApagar = Convert.ToInt32(Console.ReadLine());

valorMensalcasa = (valorcasa / anosApagar) / 12;
limiteComprometimentoSalario = salariocomprador * 0.3M;

if (limiteComprometimentoSalario > valorMensalcasa)
{
    Console.WriteLine("Compra aprovada");

}
else 
{
    Console.WriteLine("Compra negada");
}