﻿int contador = 0;

while (contador <= 18)
{
    Console.Write(contador + " ");

    contador += 3;
}

Console.Write("acabou!");
