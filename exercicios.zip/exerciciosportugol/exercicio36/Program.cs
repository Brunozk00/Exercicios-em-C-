﻿using System.ComponentModel.Design;

int quantidadeanos;
decimal salarioatual, salarioFinal;
string genero;

Console.WriteLine("Digite o gênero do funcionário: ");
genero = Console.ReadLine();

Console.WriteLine("Digite a quantos anos ele trabalha na empresa: ");
quantidadeanos = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Digite o salario do funcionario: ");
salarioatual = Convert.ToDecimal(Console.ReadLine());

if (genero.ToUpper() == "M")
{
    if (quantidadeanos < 15)
    {
        salarioFinal = salarioatual + (salarioatual * 0.05M);

    } else if (quantidadeanos < 20)
    {
        salarioFinal = salarioatual + (salarioatual * 0.12M);
    }
    else
    {
        salarioFinal = salarioatual + (salarioatual * 0.23M);
    }
}
else
{
    if (quantidadeanos < 20)
    {
        salarioFinal = salarioatual + (salarioatual * 0.03M);

    }
    else if (quantidadeanos < 30)
    {
        salarioFinal = salarioatual + (salarioatual * 0.13M);
    }
    else
    {
        salarioFinal = salarioatual + (salarioatual * 0.25M);
}
}

Console.WriteLine("O novo salário do funcionário é: R$ " + salarioFinal);